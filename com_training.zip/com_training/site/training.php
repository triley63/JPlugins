<?php

defined ( '_JEXEC' ) or die;

echo 'Front End'

?>
