<?php

defined ( '_JEXEC' ) or die;

echo "Back End";

?>
