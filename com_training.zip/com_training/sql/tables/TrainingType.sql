CREATE TABLE `#__Training_TrainingType`
(
    `trainingTypeID` int(11) NOT NULL AUTO_INCREMENT
    ,`description` varchar(25) NOT NULL
    ,PRIMARY KEY (`trainingTypeID`)
);


/* DROP INFORMATION */

DROP TABLE IF EXISTS `#__Training_TrainingType`;
