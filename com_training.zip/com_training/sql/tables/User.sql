CREATE TABLE `#__Training_User`
(
    `userID` int(11) NOT NULL AUTO_INCREMENT
    ,`userName` varchar(50) NOT NULL
    ,PRIMARY KEY (`userID`)
);


/* DROP INFORMATION */

DROP TABLE IF EXISTS `#__Training_User`
