CREATE TABLE `#__Training_TrainingStyle`
(
    `trainingStyleID` int(11) NOT NULL AUTO_INCREMENT
    ,`name` varchar(20) NOT NULL
    ,`description` varchar(255) NOT NULL
    ,PRIMARY KEY (`trainingStyleID`)
);


/* DROP INFORMATION */
DROP TABLE IF EXISTS `#__Training_TrainingStyle`;
