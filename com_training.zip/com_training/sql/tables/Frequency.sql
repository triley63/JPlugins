CREATE TABLE `#__Training_Frequency`
(
    `frequencyID` int(11) NOT NULL AUTO_INCREMENT
    ,`description` varchar(40) NOT NULL
    ,PRIMARY KEY (`frequencyID`)
);


/* DROP INFORMATION */
DROP TABLE IF EXISTS `#__Training_Frequency`;
