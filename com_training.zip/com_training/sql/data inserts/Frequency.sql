INSERT INTO `#__Training_Frequency` (`description`) VALUES ('Annual');
INSERT INTO `#__Training_Frequency` (`description`) VALUES ('Semi-Annual');
INSERT INTO `#__Training_Frequency` (`description`) VALUES ('Quarterly');
INSERT INTO `#__Training_Frequency` (`description`) VALUES ('Monthly');
INSERT INTO `#__Training_Frequency` (`description`) VALUES ('Bi-Monthly');
INSERT INTO `#__Training_Frequency` (`description`) VALUES ('Weekly');
INSERT INTO `#__Training_Frequency` (`description`) VALUES ('Bi-Weekly');
