INSERT INTO `#__TrainingType` (`description`) VALUES('Video');
INSERT INTO `#__TrainingType` (`description`) VALUES('SlideShow');
INSERT INTO `#__TrainingType` (`description`) VALUES('Document');
